#include "inner_rand_methods.h"

struct pseudo_rand_method {
  char title[16];
  int* (*run)(long long);
};

struct pseudo_rand_method new_rand_method() { 
  struct pseudo_rand_method m = { "C stdlib rand", rand_method };
  return m;
}

struct pseudo_rand_method new_xorshift_method() {
  struct pseudo_rand_method m = { "Xorshift", xorshift_method }; 
  return m;
}