#include <stdlib.h>
#include <time.h>

int* rand_method(long long qty) {
  srand((unsigned)time(NULL));
  static int occurrences[10];
  for (int i = 0; i < 10; ++i) occurrences[i] = 0;

  while(qty--) occurrences[rand() % 10]++;

  return occurrences;
}

int* xorshift_method(long long qty) {
  unsigned long long x = time(NULL);
  static int occurrences[10];
  for (int i = 0; i < 10; ++i) occurrences[i] = 0;

  while (qty--) {
    x ^= (x >> 21);
    x ^= (x << 35);
    x ^= (x >> 4);
    occurrences[x % 10]++;
  }

  return occurrences;
}